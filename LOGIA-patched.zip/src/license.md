---
layout: base.njk
title: "רישיון ושימוש"
description: "רישיון התוכן באתר LOGIA — נחלת הכלל (CC0)."
permalink: /license/
bodyClass: license-page
---

<div class="text-main" style="max-width: 760px;">

  <header class="text-header">
    <p class="text-header__eyebrow">License</p>
    <h1>רישיון ושימוש</h1>
  </header>

  <div class="text-content">

    <div class="c-info-box" style="margin-top: 0;">
      <p class="c-info-box__title">סיכום בשורה אחת</p>
      <p>כל התכנים המקוריים באתר (תרגומים, ביאורים, פתח-דברים, הערות) מופצים בנחלת הכלל (<strong>CC0 1.0</strong>) — ויתור מלא על זכויות היוצרים. ניתן להשתמש, לצטט, לשנות ולהפיץ בכל מטרה, ללא אישור וללא חיוב ייחוס.</p>
    </div>

    <h2>מה מכוסה תחת CC0</h2>

    <ul>
      <li><strong>התרגומים העבריים</strong> של הכתבים הגנוזים והחיצוניים</li>
      <li><strong>פתח-הדברים וההקדמות</strong> לכל חיבור</li>
      <li><strong>הביאורים והערות השוליים</strong></li>
      <li><strong>הנוסח המשוחזר</strong> בעברית של חיבורים שאבד מקורם</li>
      <li><strong>תרגומי המקורות הארמיים/סוריים</strong> והצגתם בתצוגה מקבילית</li>
      <li><strong>כל הטקסטים המערכתיים</strong> (אודות, מתודולוגיה, מדיניות פרטיות, דף זה)</li>
    </ul>

    <h2>מה אינו מכוסה תחת CC0</h2>

    <p>הכתבים העתיקים עצמם בלשונות מקורם — הנוסחים הסלאביים, הארמיים, הארמניים, האתיופיים, הערביים והלטיניים — הינם נחלת הכלל מאליהם, מחמת עתיקותם, ואינם דורשים רישיון. עם זאת, <strong>המהדורות המדעיות המודרניות</strong> שלהן (כגון מהדורות Brill, De Gruyter, JCTS, ואחרות) עשויות להיות מוגנות בזכויות יוצרים נפרדות של העורכים והמו"לים. המיזם אינו מפר את זכויותיהן, ומפנה אליהן בכל פתח-דבר כמקור ראשוני לעיון נוסף.</p>

    <p>בנוסף, העיצוב החזותי של האתר, הלוגו, וקוד המערכת — מופצים ברישיון נפרד וניתן לעיין בהם ב-repo הציבורי של המיזם.</p>

    <h2>הטקסט המשפטי המלא</h2>

    <p>הטקסט המלא של רישיון CC0 1.0 Universal זמין באתר Creative Commons:</p>

    <p><a href="https://creativecommons.org/publicdomain/zero/1.0/legalcode.he" rel="noopener">https://creativecommons.org/publicdomain/zero/1.0/legalcode.he</a></p>

    <p>תקציר קריא לרישיון (אינו משפטי):</p>

    <p><a href="https://creativecommons.org/publicdomain/zero/1.0/deed.he" rel="noopener">https://creativecommons.org/publicdomain/zero/1.0/deed.he</a></p>

    <h2>אזהרה מקצועית</h2>

    <p>הכתבים המתפרסמים במאגר הם יצירות מחקריות המתפתחות ומתעדכנות. אף שנעשית מאמץ לדיוק מרבי, עלולות ליפול טעויות. מי שמעוניין לצטט בהקשר אקדמי או מחקרי מוזמן לבדוק מול המקורות המצוינים בפתח-דבר של כל חיבור, ולעדכן מול הגרסה האחרונה באתר. כמו-כן, מומלץ לייחס את התרגום ל-LOGIA — לא מתוך חיוב משפטי אלא כנוהל מחקרי מקובל המאפשר לאחרים למצוא את המקור.</p>

    <h2>כיצד לצטט</h2>

    <p>המלצה לצורת ציטוט (אינה חובה משפטית):</p>

    <blockquote>
      <p><em>[שם החיבור], תרגום וביאור: LOGIA — אוצר הכתבים הגנוזים. כתובת: https://logos-alex.github.io/Source/[נתיב העמוד]. תאריך גישה: [תאריך].</em></p>
    </blockquote>

  </div>
</div>
