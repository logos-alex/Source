---
layout: text-page
title: "הדוקסולוגיה הסופית"
book: ketav-almagal
source: arabic
figure: talmidei-yeshua
pageNumber: 34
version: main
tags:
  - arabic
  - talmidei-yeshua
  - texts
permalink: /texts/arabic/ketav-almagal/page-34/
notes: []
---

### הדוקסולוגיה הסופית

ולאדוננו ואלוהינו ואדוננו ישוע המשיח --- התשבחה והגבורה והגדולה וההדר
וההשתחוויה, עם האב ורוח הקודש, מעתה ובכל עת ועד דור דורים, אמן.
