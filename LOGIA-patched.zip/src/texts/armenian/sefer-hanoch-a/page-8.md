---
layout: text-page
title: "פֶּרֶק יא"
book: sefer-hanoch-a
source: armenian
figure: enoch
pageNumber: 8
version: main
tags:
  - armenian
  - enoch
  - texts
permalink: /texts/armenian/sefer-hanoch-a/page-8/
---

### פֶּרֶק י"א

**❦ אוֹצְרוֹת הַבְּרָכָה ❦**

**^א^** וְאָז אֶפְתַּח אוֹצְרוֹת הַבְּרָכָה אֲשֶׁר בַּשָּׁמַיִם, וְהוֹרַדְתִּים אֶל הַמַּעֲשֶׂה, עַל יְגִיעַ בְּנֵי
הָאָדָם.

**^ב^** וְאָז אֱמֶת וָשָׁלוֹם יִשְׁתֻּפוּ יַחַד לְכָל יְמֵי הָעוֹלָם וּלְכָל דּוֹרוֹת בְּנֵי
הָאָדָם.
