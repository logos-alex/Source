---
layout: category-page.njk
title: "הכרעות קלימנטיניות — ספר ג (R3)"
book: clementine-r3
version: main
source: aramaic
figure: talmidei-yeshua
pageNumber: 0
draft: false
tags:
  - aramaic
  - talmidei-yeshua
  - texts
permalink: /texts/aramaic/clementine-r3/
description: "הספר השלישי של הכרעות קלימנטיניות בנוסח עברי מתוקן. המשך המסע והדרשות, כולל ויכוחים עם שמעון הקוסם והסברים על סודות הבריאה."
---

## הכרעות קלימנטיניות — ספר ג (R3)

ספר שלישי של הכרעות קלימנטיניות ממשיך את מסעו של קלמנטוס עם פטרוס, ומתמקד בוויכוחים התיאולוגיים עם שמעון הקוסם ובהסברים על סודות הבריאה. הספר מעמיק בשאלות של גאולה, השגחה, וטבע האלוהות.

הנוסח העברי ממשיך בשיטת Dynamic Geonic Rendering, ושומר על הרובד הלשוני המקראי־רבני.

**להלן פרקי הספר. ניתן לעבור ביניהם באמצעות הניווט שבתחתית כל עמוד.**
